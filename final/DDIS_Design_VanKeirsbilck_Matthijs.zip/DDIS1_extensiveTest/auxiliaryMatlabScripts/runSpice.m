convertToSpice;
execSpice;
loadHSpiceResults;